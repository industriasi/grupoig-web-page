<ul class="clearfix">
    
  <li>
<a href="http://twitter.com/home/?status=<?php the_title(); ?> - <?php the_permalink() ?>" target="_blank" title="Tweet this post">
<img src="<?php echo URL; ?>/sprites/k/twitter.png" alt="Tweet this post" />
</a>
    </li>
  <li>
<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink() ?>&amp;t=<?php the_title(); ?>" target="_blank" title="Share on Facebook">
<img src="<?php echo URL; ?>/sprites/k/facebook.png" alt="Share on Facebook" />
</a>
   </li>
    <li>
<a href="http://delicious.com/save?url=<?php the_permalink() ?>&amp;title=<?php the_title(); ?>" target="_blank" title="Bookmark on delicious">
<img src="<?php echo URL; ?>/sprites/k/delicious.png" alt="Bookmark on delicious" />
</a>
   </li>
    <li>
<a href="http://digg.com/submit?url=<?php the_permalink() ?>&amp;title=<?php the_title(); ?>" target="_blank" title="Submit to Digg">
<img src="<?php echo URL; ?>/sprites/k/digg.png" alt="Submit to Digg" />
</a>
    </li>
    <li>
<a href="http://www.stumbleupon.com/submit?url=<?php the_permalink() ?>&amp;title=<?php the_title(); ?>" target="_blank" title="Submit to stumbleupon">
<img src="<?php echo URL; ?>/sprites/k/stumbleupon.png" alt="Submit to Stumbleupon" />
</a>
    </li>
    <li>
<a href="http://www.google.com/bookmarks/mark?op=add&bkmk=<?php the_permalink() ?>&amp;title=<?php the_title(); ?>" target="_blank" title="Save to Google bookmarks">
<img src="<?php echo URL; ?>/sprites/k/google.png" alt="Save to Google bookmarks" />
</a>
  </li>
    <li>
<a href="<?php echo get_option('css_rss'); ?>" target="_blank" title="Subscribe to our RSS Feeds">
<img src="<?php echo URL; ?>/sprites/k/rss.png" alt="Subscribe to our RSS Feeds" />
</a>
  </li>
     
</ul> 