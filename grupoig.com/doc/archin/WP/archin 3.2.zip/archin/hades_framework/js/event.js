// JavaScript Document
jQuery(function($){
	
	
  jQuery(".event_datepicker").datepicker({ altFormat: 'dd-mm-yy'  , dateFormat: 'dd-mm-yy' });
  
	
	});